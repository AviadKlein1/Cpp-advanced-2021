#include "point.h"
#include <iostream>

using namespace std;

void Point ::setX(int myX)
{
	x = myX;
}
void Point::setY(int myY)
{
	y = myY;
}
int Point::getX()
{
	return x;
}
int Point::getY()
{
	return y;
}